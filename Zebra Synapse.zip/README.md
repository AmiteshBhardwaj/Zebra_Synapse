
  # Zebra Synapse

  This is a code bundle for Zebra Synapse. The original project is available at https://www.figma.com/design/K3WyblY0vqq6EYGgUiVr0y/Zebra-Synapse.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  